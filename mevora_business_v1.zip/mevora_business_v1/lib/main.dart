import 'package:flutter/material.dart';

void main() => runApp(const MevoraBusinessApp());

class MevoraBusinessApp extends StatelessWidget {
  const MevoraBusinessApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'MÉVORA BUSINESS',
      theme: ThemeData(
        useMaterial3: true,
        fontFamily: 'Arial',
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xffb47d70)),
        scaffoldBackgroundColor: const Color(0xfffff9f7),
      ),
      home: const HomeShell(),
    );
  }
}

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});
  @override State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int index = 0;
  final pages = const [
    DashboardPage(), InventoryPage(), SalesPage(), PartnersPage(), ReportsPage()
  ];
  final labels = ['الرئيسية', 'المخزون', 'المبيعات', 'الشركاء', 'التقارير'];
  final icons = [Icons.dashboard_outlined, Icons.inventory_2_outlined, Icons.receipt_long_outlined, Icons.groups_outlined, Icons.bar_chart_outlined];

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.transparent,
          title: Row(children: [
            ClipRRect(borderRadius: BorderRadius.circular(10), child: Image.asset('assets/mevora_logo.jpg', width: 42, height: 42, fit: BoxFit.cover)),
            const SizedBox(width: 10),
            const Text('MÉVORA BUSINESS', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 17)),
          ]),
        ),
        body: pages[index],
        bottomNavigationBar: NavigationBar(
          selectedIndex: index,
          onDestinationSelected: (i) => setState(() => index = i),
          destinations: [for (int i=0;i<labels.length;i++) NavigationDestination(icon: Icon(icons[i]), label: labels[i])],
        ),
      ),
    );
  }
}

class DashboardPage extends StatelessWidget {
  const DashboardPage({super.key});
  @override Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(16), children: [
    const Text('ملخص الشركة', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
    const SizedBox(height: 14),
    Wrap(spacing: 10, runSpacing: 10, children: const [
      StatCard(title:'مبيعات اليوم', value:'0 ج.م', icon:Icons.point_of_sale_outlined),
      StatCard(title:'قيمة المخزون', value:'0 ج.م', icon:Icons.inventory_outlined),
      StatCard(title:'آجل العملاء', value:'0 ج.م', icon:Icons.account_balance_wallet_outlined),
      StatCard(title:'صافي الربح', value:'0 ج.م', icon:Icons.trending_up_outlined),
    ]),
    const SizedBox(height: 20),
    Card(child: Padding(padding: const EdgeInsets.all(18), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: const [
      Text('الإجراءات السريعة', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      SizedBox(height: 14),
      QuickAction(title:'إضافة منتج', icon:Icons.add_box_outlined),
      QuickAction(title:'إنشاء فاتورة', icon:Icons.receipt_long_outlined),
      QuickAction(title:'تسجيل دفعة عميل', icon:Icons.payments_outlined),
    ]))),
  ]);
}

class StatCard extends StatelessWidget {
  final String title,value; final IconData icon;
  const StatCard({super.key,required this.title,required this.value,required this.icon});
  @override Widget build(BuildContext context) => SizedBox(width: 170, child: Card(child: Padding(padding: const EdgeInsets.all(15), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Icon(icon,size:28), const SizedBox(height:12), Text(title), const SizedBox(height:5), Text(value, style: const TextStyle(fontSize:20,fontWeight:FontWeight.bold))]))));
}

class QuickAction extends StatelessWidget { final String title; final IconData icon; const QuickAction({super.key,required this.title,required this.icon});
  @override Widget build(BuildContext context)=>ListTile(leading:Icon(icon),title:Text(title),trailing:const Icon(Icons.chevron_left),onTap:(){});
}

class InventoryPage extends StatefulWidget { const InventoryPage({super.key}); @override State<InventoryPage> createState()=>_InventoryPageState(); }
class _InventoryPageState extends State<InventoryPage> {
  final products=<Map<String,dynamic>>[];
  void addProduct(){ final name=TextEditingController(); final buy=TextEditingController(); final sell=TextEditingController(); final qty=TextEditingController(); showDialog(context:context,builder:(_)=>AlertDialog(title:const Text('إضافة منتج'),content:Column(mainAxisSize:MainAxisSize.min,children:[TextField(controller:name,decoration:const InputDecoration(labelText:'اسم المنتج')),TextField(controller:buy,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'سعر الشراء')),TextField(controller:sell,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'سعر البيع')),TextField(controller:qty,keyboardType:TextInputType.number,decoration:const InputDecoration(labelText:'الكمية'))]),actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Text('إلغاء')),FilledButton(onPressed:(){setState(()=>products.add({'name':name.text,'buy':buy.text,'sell':sell.text,'qty':qty.text}));Navigator.pop(context);},child:const Text('حفظ'))])); }
  @override Widget build(BuildContext context)=>Column(children:[Padding(padding:const EdgeInsets.fromLTRB(16,10,16,4),child:Row(children:[const Expanded(child:Text('المخزون',style:TextStyle(fontSize:24,fontWeight:FontWeight.bold))),FilledButton.icon(onPressed:addProduct,icon:const Icon(Icons.add),label:const Text('منتج'))])),Expanded(child:products.isEmpty?const Center(child:Text('لا توجد منتجات بعد\nاضغط «منتج» لإضافة أول منتج',textAlign:TextAlign.center)):ListView.builder(itemCount:products.length,itemBuilder:(c,i){final p=products[i];return Card(margin:const EdgeInsets.symmetric(horizontal:16,vertical:5),child:ListTile(title:Text(p['name']),subtitle:Text('شراء: ${p['buy']} ج.م  |  بيع: ${p['sell']} ج.م\nالكمية: ${p['qty']}'),isThreeLine:true,trailing:IconButton(icon:const Icon(Icons.delete_outline),onPressed:()=>setState(()=>products.removeAt(i))));}))]);
}

class SalesPage extends StatelessWidget { const SalesPage({super.key}); @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(16),children:[Row(children:[const Expanded(child:Text('المبيعات والفواتير',style:TextStyle(fontSize:24,fontWeight:FontWeight.bold))),FilledButton.icon(onPressed:(){},icon:const Icon(Icons.add),label:const Text('فاتورة'))]),const SizedBox(height:20),const Card(child:Padding(padding:EdgeInsets.all(20),child:Center(child:Text('لا توجد فواتير حتى الآن')))),const SizedBox(height:12),Card(child:ListTile(leading:const Icon(Icons.schedule),title:const Text('الفواتير المعلقة / الآجل'),subtitle:const Text('سيظهر هنا العملاء الذين عليهم مبالغ متبقية'),trailing:const Icon(Icons.chevron_left))) ]); }

class PartnersPage extends StatelessWidget { const PartnersPage({super.key}); @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(16),children:[Row(children:[const Expanded(child:Text('الشركاء',style:TextStyle(fontSize:24,fontWeight:FontWeight.bold))),FilledButton.icon(onPressed:(){},icon:const Icon(Icons.person_add_outlined),label:const Text('شريك'))]),const SizedBox(height:18),const Card(child:ListTile(title:Text('إجمالي رأس المال'),trailing:Text('0 ج.م',style:TextStyle(fontWeight:FontWeight.bold)))),const SizedBox(height:8),const Text('تُحسب نسبة كل شريك تلقائيًا من إجمالي المساهمات، مع إعداد منفصل لنسبة توزيع الأرباح والخسائر.',style:TextStyle(height:1.5))]); }

class ReportsPage extends StatelessWidget { const ReportsPage({super.key}); @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(16),children:[const Text('التقارير',style:TextStyle(fontSize:24,fontWeight:FontWeight.bold)),const SizedBox(height:15),for(final x in ['الأرباح والخسائر','المبيعات حسب الفترة','حركة المخزون','ديون العملاء','المصروفات والمدخلات']) Card(child:ListTile(title:Text(x),trailing:const Icon(Icons.chevron_left),onTap:(){}))]); }
